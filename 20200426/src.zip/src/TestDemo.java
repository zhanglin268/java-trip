/**
 * @program:20200426
 * @description
 * @author: 张林
 * @creat:2020-04-26 11:15
 **/
public class TestDemo {
    public static void main(String[] args) {
       /* MyList MyList1 = new MyList();
        MyList1.addlast(1);
        MyList1.addlast(2);
        MyList1.addlast(3);
        MyList1.addlast(4);
        MyList1.addlast(5);
        MyList1.addlast(6);
        MyList1.addlast(7);
        MyList1.addlast(8);
        MyList1.addFirst(0);
        MyList1.display();
        System.out.println();*/


    }
}
