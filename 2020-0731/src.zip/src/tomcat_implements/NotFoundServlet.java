package tomcat_implements;

import servlet_standard.HttpServlet;

public class NotFoundServlet extends HttpServlet {
}
