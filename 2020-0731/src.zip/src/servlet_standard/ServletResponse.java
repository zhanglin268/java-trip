package servlet_standard;

public interface ServletResponse {
}
