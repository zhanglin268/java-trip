package tool;

import java.io.File;

public class Test {

    public static void main(String[] args) {
        System.out.println(new File("").getAbsolutePath());
    }
}
